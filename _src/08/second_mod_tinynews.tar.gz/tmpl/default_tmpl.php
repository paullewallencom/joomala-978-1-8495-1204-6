<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>
<div id="tinynews">

<?php 
	foreach($news as $new){
	
		echo "<p><b>".$new->title."</b></p><br/><br/>";
		echo "<p>".$new->text."</p><br/><br/>";
		
	}
?>

</div>