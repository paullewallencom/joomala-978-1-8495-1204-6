<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

JHTML::stylesheet('styles.css','modules/mod_tinynews/css/');

$document =& JFactory::getDocument();
$document->addscript(JURI::root(true).'modules'.DS.'mod_tinynews'.DS.'js'.DS.'tinynews.js');

require_once(dirname(__FILE__).DS.'helper.php');

$news = ModTinynewsHelper::getallnews();


require(JModuleHelper::getLayoutPath('mod_tinynews','default_tmpl'));