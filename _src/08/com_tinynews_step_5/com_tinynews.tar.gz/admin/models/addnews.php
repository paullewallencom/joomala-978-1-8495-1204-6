<?php
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 
class TinynewsModelAddnews extends JModel{
		
		function &getData(){

				$array = JRequest::getVar('cid',  0, '', 'array');
				$id = $array[0];
				
        $query = ' SELECT * FROM #__tinynews WHERE id = '.$id;
        $this->_db->setQuery( $query );
        $data = $this->_db->loadObject();
		    
		    if (!$data) {
		        $data = new stdClass();
		        $data->id = 0;
		        $data->title = null;
		        $data->text = null;
		    }
		    
		    return $data;
		}
		
		function savedata(){
				
		    $row =& $this->getTable('addnews');

		    if (!$row->bind( JRequest::get( 'post' ) )) {
		        $this->setError($this->_db->getErrorMsg());
		        return false;
		    }
		 
		    if (!$row->check()) {
		        $this->setError($this->_db->getErrorMsg());
		        return false;
		    }
		 
		    if (!$row->store()) {
		        $this->setError($this->_db->getErrorMsg());
		        return false;
		    }
		 
		    return true;
		}
	
		function delete(){
		    $cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		    
		    $row =& $this->getTable('addnews');
		 
		    foreach($cids as $cid) {
		        if (!$row->delete( $cid )) {
		            $this->setError( $row->getErrorMsg() );
		            return false;
		        }
		    }
		 
		    return true;
		}

}
