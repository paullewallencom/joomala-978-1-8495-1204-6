<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
class TinynewsViewAddnews extends JView{
	
    function display(){
    	
	    $news	= $this->get('Data');
	    $exists = ($news->id < 1);
	 
	    $text = $exists ? "New" : "Edit";
	    
	    JToolBarHelper::title(   "News".': <small>[ ' . $text.' ]</small>' );
	    JToolBarHelper::save();
	    
	    if ($exists)  {
	        JToolBarHelper::cancel();
	    } else {
	        JToolBarHelper::cancel( 'cancel', 'Close' );
	    }
	 
	    $this->assignRef('news', $news);
	    parent::display();
    }
    
}