<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
class TinynewsViewTinynews extends JView{
	
    function display(){
    	
        JToolBarHelper::title('Tinynews', 'generic.png' );
        JToolBarHelper::deleteList();
        JToolBarHelper::editListX();
        JToolBarHelper::addNewX();  
    	
        $model =& $this->getModel();
        
	      $news = $model->getallnews();	      
        $this->assignRef('news', $news);
 
        parent::display();
    }
}