<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.controller');
 
class TinynewsController extends JController{
		
		function __construct(){
		    parent::__construct();
		 
		    $this->registerTask( 'add'  ,     'edit' );
		}
		
		function edit(){
		    JRequest::setVar( 'view', 'addnews' );
		    JRequest::setVar( 'layout', 'form'  );
		    JRequest::setVar('hidemainmenu', 1);
		 		
		   parent::display();
		}
		
		function remove(){
		    $model = $this->getModel('addnews');
		    
		    if(!$model->delete()) {
		        $msg = "One or more records couldn't be deleted";
		    } else {
		        $msg = "Records deleted ok";
		    }
		 
		    $this->setRedirect( 'index.php?option=com_tinynews', $msg );
		}
				
		
		function save(){
		    $model = $this->getModel('addnews');
		 
		    if ($model->savedata()) {
		        $msg = "News saved.";
		    } else {
		        $msg = "News couldn't be saved.";
		    }
		 
		    $this->setRedirect( 'index.php?option=com_tinynews', $msg);
		}

		
		function cancel(){
			$msg = "Action cancelled";
			$this->setRedirect( 'index.php?option=com_tinynews', $msg );
		}		
		
    function display(){
        parent::display();
    }
 
}