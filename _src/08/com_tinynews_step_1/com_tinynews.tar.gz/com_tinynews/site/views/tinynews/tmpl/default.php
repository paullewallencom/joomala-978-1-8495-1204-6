<?php defined('_JEXEC') or die('Restricted access'); ?>

<h1><?php echo $this->name; ?></h1>
