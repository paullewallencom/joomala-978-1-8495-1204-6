<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
class TinynewsViewTinynews extends JView{
	
    function display(){
    	
        $name = "Tinynews component!";
        $this->assignRef( 'name', $name );
 
        parent::display();
    }
}