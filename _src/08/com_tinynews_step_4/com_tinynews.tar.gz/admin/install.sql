DROP TABLE IF EXISTS `#__tinynews`;

CREATE TABLE `#__tinynews` (
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`title` VARCHAR( 255 ) NOT NULL ,
`text` TEXT NOT NULL
);
