<?php defined('_JEXEC') or die('Restricted access'); ?>

<form action="index.php" method="post" name="adminForm">
<div id="editcell">
    <table class="adminlist">
    <thead>
        <tr>
            <th width="5">
                Id
            </th>
            <th>
                Title
            </th>
            <th>
                Text
            </th>            
        </tr>            
    </thead>
    <?php
    
    $i = 0;
    foreach($this->news as $new){

    ?>
        <tr class="<?php echo "row$i"; ?>">
            <td>
                <?php echo $new->id; ?>
            </td>
            <td>
                <?php echo $new->title; ?>
            </td>
            <td>
                <?php echo $new->text; ?>
            </td>            
        </tr>
        <?php
        
        $i = 1 - $i;
    }
    ?>
    </table>
</div>
 
<input type="hidden" name="option" value="com_tinynews" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
 
</form>
