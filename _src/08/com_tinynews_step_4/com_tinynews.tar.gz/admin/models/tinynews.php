<?php
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 
class TinynewsModelTinynews extends JModel{

    function getallnews(){
    	
			$database =& JFactory::getDBO();
			
			$query = "SELECT * FROM ".$database->nameQuote('#__tinynews').";";
			
			$database->setQuery($query);
			
			$result = $database->loadObjectList();
			
			return $result;    	
    }

}
