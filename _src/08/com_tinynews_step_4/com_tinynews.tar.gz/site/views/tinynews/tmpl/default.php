<?php 

defined('_JEXEC') or die('Restricted access'); 

foreach($this->news as $new){

	echo "<p><b>".$new->title."</b></p><br/><br/>";
	echo "<p>".$new->text."</p><br/><br/>";
	
}

?>