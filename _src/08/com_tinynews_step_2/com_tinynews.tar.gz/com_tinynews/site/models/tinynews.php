<?php
 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.model' );
 
class TinynewsModelTinynews extends JModel{

    function getallnews(){
    	
    		$news[1] = "This is the title for the first news";
    		$news[2] = "This is the content for the first news";
    		$news[3] = "This is the title for the second newss";
    		$news[4] = "This is the content for the second news";    		
    	
        return $news;
    }
}
