<?php 

defined('_JEXEC') or die('Restricted access'); 

foreach($this->news as $new){

	echo "<p>".$new."</p><br/><br/>";
	
}

?>