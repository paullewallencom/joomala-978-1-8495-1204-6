<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view');
 
class TinynewsViewTinynews extends JView{
	
    function display(){
    	
        $model =& $this->getModel();
	      $news = $model->getallnews();	      
        $this->assignRef('news', $news);
 
        parent::display();
    }
}