<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

class ModTinyphotosHelper{
	
    function getallphotos(){
    	
			$database =& JFactory::getDBO();
			
			$query = "SELECT * FROM ".$database->nameQuote('#__tinynews').";";
			
			$database->setQuery($query);
			
			$result = $database->loadObjectList();
			
			return $result;    	
    }

}