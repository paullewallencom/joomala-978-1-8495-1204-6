<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>
<div id="tinyphotos">
	
	<ul>

<?php 
	foreach($news as $new){
	?>
	
		<li><img src="<?php JURI::base(); ?>administrator/components/com_tinynews/images/<?php echo $new->image; ?>" alt="<?php echo $new->caption; ?>" height="70"/></li>

	<?php	
	}
?>

	</ul>

</div>