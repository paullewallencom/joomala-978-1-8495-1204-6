<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

JHTML::stylesheet('styles.css','modules/mod_tinyphotos/css/');

$document =& JFactory::getDocument();

require_once(dirname(__FILE__).DS.'helper.php');

$news = ModTinyphotosHelper::getallphotos();


require(JModuleHelper::getLayoutPath('mod_tinyphotos','default_tmpl'));