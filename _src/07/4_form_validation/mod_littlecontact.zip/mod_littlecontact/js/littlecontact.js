jQuery(document).ready(function($){
    $('#send_button').click(function() {
        //First we do some validation, just to know that we have some data
        alerts = '';
        if($("input[name=your_name]").val() == ''){
            alerts += "- We need your name<br/>";
        }
        if($("textarea[name=your_question]").val().length < 5){
            alerts += "- We need a message of at least 5 characters length<br/>";
        }

        if(alerts != ''){
            $("#alerts").html(alerts).dialog();
        }else{
            $.post("index.php", $("#sc_form").serialize(), show_ok());
            $("#sending_message").removeClass("hidden_div");
        }
    });

    $("#message_back").click(function(e){
        e.preventDefault();
        $("#message_sent").addClass("hidden_div");
        $("#sending_message").addClass("hidden_div");
    });

    function show_ok(){
        $("#sending_message").addClass("hidden_div");
        $("#message_sent").removeClass("hidden_div");

        $("input:text").val('');
        $("textarea").val('');
    }
});

