<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>
<div id="littlecontact">
    <h1>Just a simple contact form!</h1>

    <form action="index.php" method="post" id="sc_form">
        <input type="hidden" name="form_send" value="send" />
        <label>Your name:</label><br/>
        <input type="text" name="your_name" value="" size="40" class="sc_input"/><br/><br/>

        <label>Your question:</label><br/>
        <textarea name="your_question" class="sc_input" rows="5" cols="30"></textarea><br/><br/>

        <input type="button" name="send" value="Send" class="sc_button" id="send_button"/>

    </form>

    <div id="sending_message" class="hidden_div">
         <br/><br/><br/>
        <h1>Your message is being sent, <br/>wait a bit.</h1>
    </div>

    <div id="message_sent" class="hidden_div">
         <br/><br/><br/>
        <h1>Your message has been sent. <br/>Thanks for contacting us.</h1>
        <br/><br/><br/>
        <a href="index.php" class="message_link" id="message_back">Back to the form</a>
    </div>

    <div id="alerts" title="Errors found in the form" style="display: none;"></div>
</div>