<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>
<div id="littlecontact">
    <h1>The form has been sent ok</h1>
</div>