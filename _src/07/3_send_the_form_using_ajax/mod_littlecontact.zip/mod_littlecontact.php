<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once(dirname(__FILE__).DS.'helper.php');

$document =& JFactory::getDocument();
$document->addscript(JURI::root(true).'modules'.DS.'mod_littlecontact'.DS.'js'.DS.'littlecontact.js');

JHTML::stylesheet('styles.css','modules/mod_littlecontact/css/');

$form_send = JRequest::getVar('form_send', 'notsend');

switch($form_send){

    case 'send':

        $your_name = JRequest::getVar('your_name', 'No name');
        $your_question = JRequest::getVar('your_question', 'No question');

        $send = ModLittleContactHelper::SendMail($your_name, $your_question);
        
        if ( $send !== true ) {
            echo 'Error sending email: ' . $send->message;
        } 

        require(JModuleHelper::getLayoutPath('mod_littlecontact','sendok_tmpl'));
        break;

    default:
        require(JModuleHelper::getLayoutPath('mod_littlecontact','default_tmpl'));

}

?>