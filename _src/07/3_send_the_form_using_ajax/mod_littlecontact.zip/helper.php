<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

class ModLittleContactHelper{

    public function SendMail($your_name, $your_question){

        $mail =& JFactory::getMailer();
        $mail->setSender('josemanises@gmail.com', 'Wayofthewebninja');
        $mail->setSubject('Contact from our site');
        $mail->addRecipient('josemanises@gmail.com');

        $body = "Contact form send by user<br/>";
        $body.= "-------------------------<br/>";
        $body.= "Username: ".$your_name."<br/>";
        $body.= "Question: ".$your_question."<br/>";

        $mail->setBody($body);
        $mail->IsHTML(true);

        $send =& $mail->Send();

        return $send;
    }
}
?>