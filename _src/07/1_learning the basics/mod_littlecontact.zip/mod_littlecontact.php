<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
?>
<h1>Just a simple contact form!</h1>
